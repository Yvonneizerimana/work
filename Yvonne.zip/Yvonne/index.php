<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>leandre</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background:">
<div class="container" >
	<div class="row">
		<div class="col-md-6" >
			<h1 style="font:bold;">Fill the form.</h1>
			<h1 style="font:bold;">It's easy.</h1>
			<form method="post" action="">
				<input type="text" name="user" class="middle" id="user" tabindex="1" />&nbsp;&nbsp;&nbsp;
				<input type="text" name="lastname" placeholder="last name" >
			</form>

		</div>
		<div class="col-md-6">

		</div>
	</div>
</div>
</body>
</html>